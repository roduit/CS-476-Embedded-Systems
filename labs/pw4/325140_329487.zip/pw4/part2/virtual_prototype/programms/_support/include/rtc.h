#ifndef __RTC_H__
#define __RTC_H__

void printTimeComplete();
#endif
