# Virtual Prototype - Filippo Quadri & Vincent Roduit

All the verilog file (`profileCi.v` and `counter.v`) can be found in the folder `systems/singleCore/verilog`
We've also modified the file `or1420SingleCore.v` in the same folder (to instantiate the module)

The file `grayscale.c`, that can be found in the folder `programms/grayscale/src`, also presents some modifications.
